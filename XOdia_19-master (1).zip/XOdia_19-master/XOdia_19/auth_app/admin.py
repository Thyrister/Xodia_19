# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.contrib import admin
from auth_app.models import Profile
# Register your models here.
admin.site.register(Profile)
