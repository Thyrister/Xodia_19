import os
path = os.getcwd() + '/'
project_base_dir = os.path.dirname(os.getcwd()) + '/'
django_log_file = open(path + "django_logs", 'w')
