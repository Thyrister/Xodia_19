from os import getcwd
path = getcwd()
